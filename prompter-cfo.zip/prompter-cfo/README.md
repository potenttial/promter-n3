# Prompter CFO by N3

Constructor de prompts para el Agente Orquestador del CFO y sus 16 agentes verticales.
Funciona en el navegador y no consume tokens.

- `index.html`: el Prompter.
- `casos/`: 6 casos financieros hipotéticos en Excel para practicar con el Prompter.

© 2026 N3 Thinktech IA Laboratory · Potenttial Group
